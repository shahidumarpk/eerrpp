<?php
class mod_projects extends CI_Model {
	
	function __construct(){
		
        parent::__construct();
    }

	//Verify If User is Login on the authorized Pages.
	public function verify_is_admin_login(){
		
		if(!$this->session->userdata('customer_id')){
			

			$this->session->set_flashdata('err_message', '- You have to login to access this page.');
			redirect(base_url().'login/login');
			
		}//if(!$this->session->userdata('id'))
		
	}//end verify_is_user_login()



    //Get projects  Record
	public function get_projects(){
		
		
		$this->db->dbprefix('projects');
		$this->db->select('projects.*,customers.first_name,customers.last_name');
        $this->db->from('projects');
        $this->db->join('customers', 'projects.customer_id = customers.id');
		$this->db->where('projects.customer_id',$this->session->userdata('customer_id'));
		$this->db->order_by('projects.customer_id',DESC);
		$get_projects= $this->db->get();

		//echo $this->db->last_query();
		
		$row_projects['projects_arr'] = $get_projects->result_array();
		$row_projects['projects_count'] = $get_projects->num_rows;
		
		return $row_projects;
		
	}//end Project Records


	
	public function get_project_details($project_id){
		
	
		$this->db->dbprefix('projects');
		$this->db->where('id',$project_id);
		$get_messages= $this->db->get('projects');
        //echo $this->db->last_query();
		$project_detail_arr['project_detail_result'] = $get_messages->row_array();
		
		//Get Project Attachments
		$this->db->dbprefix('project_attachments');
		$this->db->where('project_id',$project_id);
		$get_project_attachments= $this->db->get('project_attachments');
		
		$project_detail_arr['project_attachments'] = $get_project_attachments->result_array();
		$project_detail_arr['project_attachments_count'] = $get_project_attachments->num_rows;
		
		
		return $project_detail_arr;		
		
	}//end get_project_details
	

	
    public function project_detail($project_id){
		
		$this->db->dbprefix('projects');
		
		$this->db->select('projects.*,customers.first_name,customers.last_name,customers.id');
        $this->db->from('projects');
        $this->db->join('customers', 'projects.customer_id = customers.id');
		$this->db->where('projects.id',$project_id);
		$get_project_details= $this->db->get();
		
		
		
		//Get Project Attachments
		$this->db->dbprefix('project_attachments');
		$this->db->where('project_id',$project_id);
		$get_project_attachments= $this->db->get('project_attachments');
		
		$get_project_details_arr['project_attachments'] = $get_project_attachments->result_array();
		$get_project_details_arr['project_attachments_count'] = $get_project_attachments->num_rows;
		
        //echo $this->db->last_query();
		
		$get_project_details_arr['project_details_result'] = $get_project_details->row_array();
		
		
		$project_assign_id= explode(',',$get_project_details_arr['project_details_result']['project_assign']);
		
		$customer_id= $get_project_details_arr['project_details_result']['customer_id'];
		
		if($this->session->userdata('customer_id')==$customer_id){
			
			
			for($i=0;$i<count($project_assign_id); $i++){
			
			$this->db->dbprefix('admin');
			$this->db->select('id,admin_role_id,first_name,last_name');
			$this->db->from('admin');
			$this->db->where('id',$project_assign_id[$i]);
			$get_user= $this->db->get();
			$get_user_arr['user_arr'] = $get_user->row_array();
	  $get_project_details_arr['project_assign_team'][$i]['user_name']= $get_user_arr['user_arr']['first_name']." ".$get_user_arr['user_arr']['last_name'];
	  
	 $get_project_details_arr['project_assign_team'][$i]['id']= $get_user_arr['user_arr']['id'];
	  
	          $admin_role_id= $get_user_arr['user_arr']['admin_role_id']; 
			  $this->db->dbprefix('admin_roles');
			  $this->db->select('role_title');
			  $this->db->from('admin_roles');
			  $this->db->where('id',$admin_role_id);
			  $get_role= $this->db->get();
			  $get_role_arr['user_arr'] = $get_role->row_array();
			  
			  $get_project_details_arr['role'][$i]=$get_role_arr['user_arr']['role_title'];
			  
			
			}
	    /*  echo "<pre>";	
		   print_r( $get_project_details_arr);	
		
	        exit;*/
		return $get_project_details_arr;
			
		
			
		}else{
			
			return  $get_project_details_arr['error']= array('error' =>"Opps...! Project not found...!!");
			
		}
		
		
				
		
	}//end get_messages
	

	public function project_messages($data){
		
		extract($data);
		
		 $created_date = date('Y-m-d G:i:s');
		 $created_by_ip = $this->input->ip_address();
		 $created_by = $this->session->userdata('admin_id');
		 
		$insrt_data = array(
		    'project_id' => $this->db->escape_str(trim($project_id)),
		    'to' => $this->db->escape_str(trim('1')),
			'from' => $this->db->escape_str(trim($from)),
			'message' => $this->db->escape_str(trim(nl2br($message_reply))),
			'user_type' => $this->db->escape_str('c'),
			'created_by' => $this->db->escape_str(trim($created_by)),
		    'created_date' => $this->db->escape_str(trim($created_date)),
		    'created_by_ip' => $this->db->escape_str(trim($created_by_ip))
		);		

		//inserting the record into the database.
		$this->db->dbprefix('project_messages');
		$upd_into_db = $this->db->insert('project_messages', $insrt_data);
		$message_id= $this->db->insert_id();
		
		
		for($i=0; $i<count($_FILES['attachments']['name']); $i++)
		   
		   {	
			
		   if($_FILES['attachments']['name'][$i] !=""){
			   
			   
		     $project_folder_path = '../assets/project_attachments/'.$project_id."/";
		     $attachment_name = "project_message_".$message_id.'_'.$_FILES['attachments']['name'][$i] ; 
		   
			 $ins_attachment = array(
			    'project_id' => $this->db->escape_str(trim($project_id)),
				'project_message_id' => $this->db->escape_str(trim($message_id)),
				'attachments' => $this->db->escape_str(trim($attachment_name)),
				'created_by' => $this->db->escape_str(trim($created_by)),
				'created_date' => $this->db->escape_str(trim($created_date)),
				'created_by_ip' => $this->db->escape_str(trim($created_by_ip))
			 );			
	
		
		   //Inserting the record into the database.
		    $this->db->dbprefix('project_messages_attachments');
		    $ins_into_db = $this->db->insert('project_messages_attachments', $ins_attachment);
			
			
		 }//End for loop
			
			$this->load->helper(array('form', 'url'));
			$config['upload_path'] = $project_folder_path;
			$config['allowed_types'] = 'jpg|jpeg|gif|tiff|png|doc|docx|xls|xlsx|pdf|txt';
			$config['max_size']	= '6000';
			$config['overwrite'] = true;
	
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$this->load->library('multipleupload',$config);

			$upload_epaper =  $this->multipleupload->do_multi_upload_project_message_attachments('attachments',TRUE,$message_id);
			//echo $this->db->last_query(); exit;
			
		   }//End for loop if attachment is not empty
		
		
	     return true;
		
	}//end project_messages
	
	
	public function get_message_attachments($project_id){
		
		$this->db->dbprefix('project_messages_attachments');
		$this->db->where('project_id',$project_id);
		$get_messages_attachments = $this->db->get('project_messages_attachments');
		
		$message_att_arr = $get_messages_attachments->result_array();
		
		$final_message_attach_arr = array();
		
		//echo $this->db->last_query(); exit;
		for($i=0;$i<count($message_att_arr);$i++){
			
			$final_message_attach_arr[$message_att_arr[$i]['project_message_id']][] = $message_att_arr[$i]['attachments'];
			
		}//end for
		//print_r($final_message_attach_arr);
	
		return $final_message_attach_arr;
		
	}//end get_message_attachments
	
	public function get_project_messages($project_id){
	
		$this->db->dbprefix('project_messages');
		$this->db->where('project_id',$project_id);
		$this->db->order_by('id',DESC);
		$get_project_messages= $this->db->get('project_messages');
        //echo $this->db->last_query();
		$get_project_messages_arr['project_messages_result'] = $get_project_messages->result_array();
		$get_project_messages_arr['project_messages_count'] = $get_project_messages->num_rows();
		
		
		for($i=0; $i<$get_project_messages_arr['project_messages_count']; $i++)
		{
			
		   $user_type=$get_project_messages_arr['project_messages_result'][$i]['user_type'];
		   $from=$get_project_messages_arr['project_messages_result'][$i]['from'];
		
		if($user_type=='u'){
			
		       $this->db->dbprefix('admin');
		       $this->db->where('id',$from);
		       $get_project_messages= $this->db->get('admin');
			   $name_array= $get_project_messages->row_array();
			   
			  $get_project_messages_arr['project_messages_result'][$i]['user']= $name_array['first_name']." ".$name_array['last_name'];
			   
			
			}
		if($user_type=='c'){
			
		      $this->db->dbprefix('customers');
		      $this->db->where('id',$from);
		      $get_project_messages= $this->db->get('customers');
		      $name_array= $get_project_messages->row_array();
			  $get_project_messages_arr['project_messages_result'][$i]['user']= $name_array['first_name']." ".$name_array['last_name'];
			
			}
			
			
		}//End for
		
		
		return $get_project_messages_arr;		
		
	}//end get_project_messages
	
	
	
	public function get_messages_count(){
		
		$this->db->dbprefix('project_messages');
		$this->db->select('project_id, COUNT(status) as num_messages');
	    $this->db->where('user_type','u');
		$this->db->where('to',$this->session->userdata('customer_id'));
		$this->db->where('status',0);
		$this->db->group_by('project_id');
		$get_messages= $this->db->get('project_messages');
		$message_att_arr['message_arr'] = $get_messages->result_array();
		$message_att_arr['message_count'] = $get_messages->num_rows();
	//	echo $this->db->last_query(); exit;
		

		for($i=0; $i<$message_att_arr['message_count']; $i++){
			
			$project_id=$message_att_arr['message_arr'][$i]['project_id'];
			  
		      $this->db->dbprefix('projects');
		      $this->db->where('id',$project_id);
		      $get_project_messages= $this->db->get('projects');
		      $name_array= $get_project_messages->row_array();
			
			  $message_att_arr['message_arr'][$i]['project_title']= $name_array['project_title'];
			
			}
		
		return $message_att_arr;
		
	}//get_messages_count
	
	
	public function update_project_messages_count($project_id){
		
		
		$upd_data = array(
		    'status' => $this->db->escape_str(trim(1))
		);		
		$this->db->dbprefix('project_messages');
		$this->db->where('project_id',$project_id);
		$this->db->where('user_type','u');
		$get_messages= $this->db->update('project_messages',$upd_data);
	
		return true;
		
	}//End update_project_messages_count
	
	
	public function get_project_tasks($project_id){
		
	
		$this->db->dbprefix('project_task');
		$this->db->where('project_id',$project_id);
		$get_tasks= $this->db->get('project_task');
        //echo $this->db->last_query();
		//$project_task_arr['project_task_result'] = $get_tasks->result_array();
		$project_task_count= $get_tasks->num_rows();
		
		$this->db->where('project_id',$project_id);
		$this->db->where('status',1);
		$get_open_task= $this->db->get('project_task');
        //echo $this->db->last_query();
		$get_open_task_count= $get_open_task->num_rows();
		
		$this->db->where('project_id',$project_id);
		$this->db->where('status',2);
		$get_hold_task= $this->db->get('project_task');
        //echo $this->db->last_query();
		$get_hold_task_count= $get_hold_task->num_rows();
		
		$this->db->where('project_id',$project_id);
		$this->db->where('status',3);
		$get_closed_task= $this->db->get('project_task');
        //echo $this->db->last_query();
		$get_closed_task_count= $get_closed_task->num_rows();
		
		
		 $project_task_arr['total_task']=$project_task_count;
		 $project_task_arr['open_task']=$get_open_task_count;
		 $project_task_arr['hold_task']=$get_hold_task_count;
		 $project_task_arr['closed_task']=$get_closed_task_count;
		 
		
		 $where="(status=0 or status=1)";
		 
		 $this->db->dbprefix('project_task');
		 $this->db->where('project_id',$project_id);
		 $this->db->where($where);
		 $this->db->order_by('id',DESC);
		 $this->db->limit(10);
		 $get_project_task_arr= $this->db->get('project_task');
         //echo $this->db->last_query();exit;
		 $project_task_arr['project_task_result'] = $get_project_task_arr->result_array();
		
		/*echo "<pre>";
		print_r( $project_task_arr['project_task_result']);
		exit;*/
		
	
		return $project_task_arr;		
		
	}//end get_project_tasks
}
?>